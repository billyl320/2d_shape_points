rm(list=ls())


library(xtable) #for table creation for latex
library(e1071)#for svm
library(caret)#for more info on training rf
library(randomForest)#for more info on training rf

#reporting session info
sessionInfo()


#shape metrics
da_1 = read.table('tad1_SHAPES.txt', sep=',', header=TRUE)
da_2 = read.table('tad2_SHAPES.txt', sep=',', header=TRUE)
da_3 = read.table('tad3_SHAPES.txt', sep=',', header=TRUE)
da_4 = read.table('tad4_SHAPES.txt', sep=',', header=TRUE)

data = rbind(da_1, da_2, da_3, da_4)

#eis
ei_1 = read.table('tad1.txt', sep=',', header=TRUE)
ei_2 = read.table('tad2.txt', sep=',', header=TRUE)
ei_3 = read.table('tad3.txt', sep=',', header=TRUE)
ei_4 = read.table('tad4.txt', sep=',', header=TRUE)

ei = rbind(ei_1, ei_2, ei_3, ei_4)
#obtaining sp values
sp<-ei[,1]/(ei[,1]+ei[,2])


labs2<-as.factor(c(
                  rep("One", dim(ei_1)[1]),
                  rep("Two", dim(ei_2)[1]),
                  rep("Three", dim(ei_3)[1]),
                  rep("Four", dim(ei_4)[1])
                  ) )


labs<-as.factor(c(
                  rep(1, dim(ei_1)[1]),
                  rep(2, dim(ei_2)[1]),
                  rep(3, dim(ei_3)[1]),
                  rep(4, dim(ei_4)[1])
                  ) )

#counts plot
temp<-as.data.frame(cbind(ei,sp, data))


#setup for rf model

train<-as.data.frame(cbind(as.factor(labs), temp))
colnames(train)[1]<-"labs_svm"

#variables to keep
keep<-c(1:7)

#now let's tune the svm model using 5-folds on t-set and validaiton

set.seed(28956)

keep1<-which(train$labs_svm==1)
keep2<-which(train$labs_svm==2)
keep3<-which(train$labs_svm==3)
keep4<-which(train$labs_svm==4)

#80% for training and 20% for validation
obs_1 = keep1[1:floor(length(keep1)*0.80)]
obs_2 = keep2[1:floor(length(keep2)*0.80)]
obs_3 = keep3[1:floor(length(keep3)*0.80)]
obs_4 = keep4[1:floor(length(keep4)*0.80)]

obs<-c(obs_1, obs_2, obs_3, obs_4)

#cv setup
tc <- trainControl(method='cv',
                  number = 5,
                  search='grid')

grid <- expand.grid(mtry=c(1:10))

#perform cv random forest
tune.out<-train(as.factor(labs_svm) ~.,
          data=train[obs, keep],
          method='rf',
          importance=TRUE,
          trControl = tc,
          tuneGrid=grid)

#print results
print(tune.out)

w<-as.matrix(tune.out$finalModel$importance[,3])
w_sort<-w[order(-w[,1]), , drop = FALSE]

#max weight
w_max<-(w_sort[1])

#normalized weights relative to the max
w_norm<- w_sort / w_max

#table for Latex
#normalized
xtable(as.matrix(w_norm), digits=3)

#table for Latex
#non normalized
xtable(as.matrix(w), digits=3)

varImp(tune.out$finalModel)

varImp(tune.out)

#output accuracy on training data
ypred=predict(tune.out$finalModel ,train[obs,])
table(predict=ypred, truth=train$labs_svm[obs])
mean(ypred==train$labs_svm[obs])

#confusion matrix
confusionMatrix(ypred, train$labs_svm[obs])

#setup matrix to collect scores
#measures_train<-matrix(nrow=2, ncol=3, data=0 )
#rownames(measures_train)<-c('0', '1')
#colnames(measures_train)<-c("Precision", "Recall", "F-1 Score")

#collecting measures
#precision <- posPredValue(ypred, train$labs_svm[obs], positive="0")
#recall <- sensitivity(ypred, train$labs_svm[obs], positive="0")
#F1 <- (2 * precision * recall) / (precision + recall)
#measures_train[1,1]<-precision
#measures_train[1,2]<-recall
#measures_train[1,3]<-F1

#precision <- posPredValue(ypred, train$labs_svm[obs], positive="1")
#recall <- sensitivity(ypred, train$labs_svm[obs], positive="1")
#F1 <- (2 * precision * recall) / (precision + recall)
#measures_train[2,1]<-precision
#measures_train[2,2]<-recall
#measures_train[2,3]<-F1

#xtable(measures_train)

#colMeans(measures_train)

#collecting accuracy on validation data
ypred=predict(tune.out$finalModel ,train[-obs,])
table(predict=ypred, truth=train$labs_svm[-obs])
mean(ypred==train$labs_svm[-obs])

#confusion matrix for validation data
confusionMatrix(ypred, train$labs_svm[-obs])

#matrix for validation data measures
#measures_valid<-matrix(nrow=2, ncol=3, data=0 )
#rownames(measures_valid)<-c('0', '1')
#colnames(measures_valid)<-c("Precision", "Recall", "F-1 Score")

#collecting measures
#precision <- posPredValue(ypred, train$labs_svm[-obs], positive="0")
#recall <- sensitivity(ypred, train$labs_svm[-obs], positive="0")
#F1 <- (2 * precision * recall) / (precision + recall)
#measures_valid[1,1]<-precision
#measures_valid[1,2]<-recall
#measures_valid[1,3]<-F1

#precision <- posPredValue(ypred, train$labs_svm[-obs], positive="1")
#recall <- sensitivity(ypred, train$labs_svm[-obs], positive="1")
#F1 <- (2 * precision * recall) / (precision + recall)
#measures_valid[2,1]<-precision
#measures_valid[2,2]<-recall
#measures_valid[2,3]<-F1

#xtable(measures_valid)

#colMeans(measures_valid)


#scatterplot of data
plot(temp[,keep], col=labs)

#simpler using mann-whitney
#mw<-wilcox.test(temp$sp ~ labs,
#                na.rm=TRUE,
#                paired=FALSE,
#                exact=FALSE,
#                conf.int=TRUE)

#mw

boxplot(temp$sp ~ labs,
        ylab='SP',
        xlab='Mixture of Gaussians; 1=Tad1, 2=Tad2, 3=Tad3, 4=Tad4',
        main='Boxplot of SP for Multivariate Normals'
      )

#
