#
import numpy as np
import convert as cvt
import matplotlib.pyplot as plt
import random
import scipy.misc as sm
import imageio as ii


#example to show that SP is usable on multivariate normal
random.seed(9522)

#random normal
mean = np.array((0,0))
cov1 = np.array( ( (1, 0), (0, 1) ) )
cov2 = np.array( ( (1, 0.9), (0.9, 1) ) )

#creating 100 random samples for each distribution
i=0
for i in range(100):
    #create random samples
    x1, y1 = np.random.multivariate_normal(mean, cov1, 1000).T
    x2, y2 = np.random.multivariate_normal(mean, cov2, 1000).T
    #convert dist1 to image
    H, xedges, yedges = np.histogram2d(x=x1, y=y1, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/dist1/dist1_'+str(i)+'.png', img)
    #convert dist2 to image
    H, xedges, yedges = np.histogram2d(x=x2, y=y2, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/dist2/dist2_'+str(i)+'.png', img)


#collecting shape metrics

#dist1 class
dist1 = ["data/dist1", "none"]

#name of .txt file
name = 'dist1.txt'
name2 = 'dist1'

#converting images
cvt.BinaryHistTXT(name, dist1)
cvt.BinaryShapesTXT(name2, dist1)

#dist2 class
dist2 = ["data/dist2", "none"]

#name of .txt file
name = 'dist2.txt'
name2 = 'dist2'

#converting images
cvt.BinaryHistTXT(name, dist2)
cvt.BinaryShapesTXT(name2, dist2)


#
