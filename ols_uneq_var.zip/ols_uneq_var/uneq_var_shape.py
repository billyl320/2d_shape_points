#
import numpy as np
import convert as cvt
import matplotlib.pyplot as plt
import random
import scipy.misc as sm
import imageio as ii
from scipy.stats import linregress

#set seed
random.seed(5401324)

#creating 100 random samples for each distribution
i=0
for j in range(100):
    #create random samples
    #typical OLS
    x1 = np.random.normal(0, 1, 1000).T
    y1 = np.zeros(1000)
    for i in range(1000):
        y1[i] = (3*x1[i])+np.random.normal(0, 1, 1).T
    slope, intercept, r, p, se = linregress(x1, y1)
    yhat1 = intercept + (slope*x1)
    res1 = y1-yhat1
    #poisson
    x2 = np.random.normal(10, 3, 1000).T
    y2 = np.zeros(1000)
    for i in range(1000):
        if x2[i]>0:
            y2[i] = np.random.poisson(lam=x2[i], size=1).T
        else:
            x2[i]=0
            y2[i] = np.random.poisson(lam=x2[i], size=1).T
    slope, intercept, r, p, se = linregress(x2, y2)
    yhat2 = intercept + (slope*x2)
    res2 = y2-yhat2
    #sample 3
    m=50
    y3 = np.random.binomial(n=m, p=0.50, size=1000).T
    x3 = np.zeros(1000)
    for i in range(1000):
        x3[i] = ((y3[i]-np.random.normal(0, 1, 1).T) /5)
    slope, intercept, r, p, se = linregress(x3, y3)
    yhat3 = intercept + (slope*x3)
    res3 = y3-yhat3
    #multiplicative errors
    x4 = np.random.normal(0, 1, 1000).T
    y4 = np.zeros(1000)
    for i in range(1000):
        y4[i] = (5*x4[i])*np.random.normal(0, 1, 1).T
    slope, intercept, r, p, se = linregress(x4, y4)
    yhat4 = intercept + (slope*x4)
    res4 = y4-yhat4
    #convert dist1 to image
    H, xedges, yedges = np.histogram2d(x=yhat1, y=res1, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/mod1/'+str(j)+'.png', img)
    #convert dist2 to image
    H, xedges, yedges = np.histogram2d(x=yhat2, y=res2, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/mod2/'+str(j)+'.png', img)
    #convert dist3 to image
    H, xedges, yedges = np.histogram2d(x=yhat3, y=res3, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/mod3/'+str(j)+'.png', img)
    #convert dist4 to image
    H, xedges, yedges = np.histogram2d(x=yhat4, y=res4, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/mod4/'+str(j)+'.png', img)


#collecting shape metrics

#dist1 class
dist1 = ["data/mod1", "none"]

#name of .txt file
name = 'dist1.txt'
name2 = 'dist1'

#converting images
cvt.BinaryHistTXT(name, dist1)
cvt.BinaryShapesTXT(name2, dist1)

#dist2 class
dist2 = ["data/mod2", "none"]

#name of .txt file
name = 'dist2.txt'
name2 = 'dist2'

#converting images
cvt.BinaryHistTXT(name, dist2)
cvt.BinaryShapesTXT(name2, dist2)

#dist3 class
dist3 = ["data/mod3", "none"]

#name of .txt file
name = 'dist3.txt'
name3 = 'dist3'

#converting images
cvt.BinaryHistTXT(name, dist3)
cvt.BinaryShapesTXT(name3, dist3)

#dist4 class
dist4 = ["data/mod4", "none"]

#name of .txt file
name = 'dist4.txt'
name4 = 'dist4'

#converting images
cvt.BinaryHistTXT(name, dist4)
cvt.BinaryShapesTXT(name4, dist4)

#
