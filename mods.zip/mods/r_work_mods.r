#r code to simulate different relationships

set.seed(585775)

#setup
n<-1000
y1<-rep(0, n)
y2<-rep(0, n)
y3<-rep(0, n)
y4<-rep(0, n)

#linear model
x1<-rnorm(n, 0, 10)

for (i in 1:n) {

  y1[i] = 3*x1[i]+rnorm(1, 0, 1)

}

#y=sin(x)+error
x2<-rnorm(n, 0, 10)

for (i in 1:n) {

  y2[i] = 4*sin(x2[i])+rnorm(1, 0, 0.5)

}

#y=x^2 +error
x3<-rnorm(n, 0, 2)

for (i in 1:n) {

  y3[i] = ((x3[i])^2)+rnorm(1, 0, 0.5)

}

#y = (x^4) + (10x^3) - (7x^2) + error
x4<-rnorm(n, 0, 2)

for (i in 1:n) {

  y4[i] = (x4[i]^4) + (10*x4[i]^3) - (7*x4[i]^2) + rnorm(1, 0, 2)

}



#
