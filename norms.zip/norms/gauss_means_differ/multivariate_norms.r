rm(list=ls())


library(xtable) #for table creation for latex
library(e1071)#for svm
library(caret)#for more info on training rf

#reporting session info
sessionInfo()


#shape metrics
da_1 = read.table('norm_den/dist1_SHAPES.txt', sep=',', header=TRUE)
da_2 = read.table('norm_den/dist2_SHAPES.txt', sep=',', header=TRUE)

data = rbind(da_1, da_2)

#eis
ei_1 = read.table('norm_den/dist1.txt', sep=',', header=TRUE)
ei_2 = read.table('norm_den/dist2.txt', sep=',', header=TRUE)

ei = rbind(ei_1, ei_2)
#obtaining sp values
sp<-ei[,1]/(ei[,1]+ei[,2])


labs2<-as.factor(c(
                  rep("One", dim(ei_1)[1]),
                  rep("Two", dim(ei_2)[1])    ) )


labs<-as.factor(c(
                  rep(1, dim(ei_1)[1]),
                  rep(0, dim(ei_2)[1])    ) )

#counts plot
temp<-as.data.frame(cbind(ei,sp, data))


#setup for rf model

train<-as.data.frame(cbind(as.factor(labs), temp))
colnames(train)[1]<-"labs_svm"

#variables to keep
keep<-c(1:7)

#now let's tune the svm model using 5-folds on t-set and validaiton

set.seed(42143)

keep2<-which(train$labs_svm==1)
keep3<-which(train$labs_svm==0)

#80% for training and 20% for validation
obs_1 = keep2[1:floor(length(keep2)*0.80)]
obs_2 = keep3[1:floor(length(keep3)*0.80)]

obs<-c(obs_1, obs_2)

#cv setup
tc <- trainControl(method='cv',
                  number = 5,
                  search='grid')

grid <- expand.grid(cp=seq(0, 0.2, by=0.01))

#perform cv random forest
tune.out<-train(as.factor(labs_svm) ~.,
          data=train[obs, keep],
          method='rpart',
          trControl = tc,
          tuneGrid=grid)

#print results
print(tune.out)

#output accuracy on training data
ypred=predict(tune.out$finalModel ,train[obs,], type='class')
table(predict=ypred, truth=train$labs_svm[obs])
mean(ypred==train$labs_svm[obs])

#confusion matrix
confusionMatrix(ypred, train$labs_svm[obs])

#collecting accuracy on validation data
ypred=predict(tune.out$finalModel ,train[-obs,], type='class')
table(predict=ypred, truth=train$labs_svm[-obs])
mean(ypred==train$labs_svm[-obs])

#confusion matrix for validation data
confusionMatrix(ypred, train$labs_svm[-obs])

plot(tune.out$finalModel, uniform=TRUE,
     main="Classification Tree")
text(tune.out$finalModel, all=TRUE, cex=.8)
#scatterplot of data
plot(temp[,keep], col=labs)

boxplot(temp$sp ~ labs,
        ylab='SP',
        xlab='Multivariate Normal; 1=Dist1, 0=Dist2',
        main='Boxplot of SP for Multivariate Normals'
      )

#
