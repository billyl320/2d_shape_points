#r work for setting up unequal variances

set.seed(1)

#poisson response
n=10000
x<-rnorm(n, 10, 3)
y<-rep(0, n)

for (i in 1:n) {

    if(x[i]>0){
      y[i]<- rpois(n=1, lambda=(x[i]) )
    }
    else{
      x[i]=0
      y[i]<-rpois(n=1, lambda=(x[i]) )
    }

}

fit_m<-lm(y~x)
summary(fit_m)
plot(fit_m)


#expoential response
y<-rexp(n, rate=1.5)
x<-rep(0, n)

for (i in 1:n) {

  x[i]<- ((y[i]-rnorm(1, 0, 1)) /5)

}

fit_e<-lm(y~x)
summary(fit_e)
plot(fit_e)

#proportion response
m=50
y<-rbinom(n, size=m, prob=0.50)/m
x<-rep(0, n)

for (i in 1:n) {

  x[i]<- ((y[i]-rnorm(1, 0, 1)) /5)

}

fit_b<-lm(y~x)
summary(fit_b)
plot(fit_b)


#multiplicative response
x<-rnorm(n, 0, 1)
y<-rep(0, n)

for (i in 1:n) {

  y[i]<- (5*x[i])*rnorm(1, 0, 1)

}

fit_m<-lm(y~x)
summary(fit_m)
plot(fit_m)

#typical setup response
x<-rnorm(n, 0, 1)
y<-rep(0, n)

for (i in 1:n) {

  y[i]<- (13*x[i])+rnorm(1, 0, 1)

}

fit_o<-lm(y~x)
summary(fit_o)
plot(fit_o)


#
