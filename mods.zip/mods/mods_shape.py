#
import numpy as np
import convert as cvt
import matplotlib.pyplot as plt
import random
import scipy.misc as sm
import imageio as ii

#set seed
random.seed(62960604)

#creating 100 random samples for each distribution
i=0
for j in range(100):
    #create random samples
    #sample 1
    x1 = np.random.normal(0, 10, 1000).T
    y1 = np.zeros(1000)
    for i in range(1000):
        y1[i] = (3*x1[i])+np.random.normal(0, 1, 1).T
    #sample 2
    x2 = np.random.normal(0, 10, 1000).T
    y2 = np.zeros(1000)
    for i in range(1000):
        y2[i] = 4*np.sin(x2[i])+np.random.normal(0, 0.5, 1).T
    #sample 3
    x3 = np.random.normal(0, 10, 1000).T
    y3 = np.zeros(1000)
    for i in range(1000):
        y3[i] = ((x3[i])**2)+np.random.normal(0, 1, 1).T
    #sample 4
    x4 = np.random.normal(0, 10, 1000).T
    y4 = np.zeros(1000)
    for i in range(1000):
        y4[i] = (x4[i]**4) + (10*x4[i]**3) - (7*x4[i]**2)+np.random.normal(0, 2, 1).T
    #convert dist1 to image
    H, xedges, yedges = np.histogram2d(x=x1, y=y1, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/mod1/'+str(j)+'.png', img)
    #convert dist2 to image
    H, xedges, yedges = np.histogram2d(x=x2, y=y2, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/mod2/'+str(j)+'.png', img)
    #convert dist3 to image
    H, xedges, yedges = np.histogram2d(x=x3, y=y3, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/mod3/'+str(j)+'.png', img)
    #convert dist4 to image
    H, xedges, yedges = np.histogram2d(x=x4, y=y4, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/mod4/'+str(j)+'.png', img)


#collecting shape metrics

#dist1 class
dist1 = ["data/mod1", "none"]

#name of .txt file
name = 'dist1.txt'
name2 = 'dist1'

#converting images
cvt.BinaryHistTXT(name, dist1)
cvt.BinaryShapesTXT(name2, dist1)

#dist2 class
dist2 = ["data/mod2", "none"]

#name of .txt file
name = 'dist2.txt'
name2 = 'dist2'

#converting images
cvt.BinaryHistTXT(name, dist2)
cvt.BinaryShapesTXT(name2, dist2)

#dist3 class
dist3 = ["data/mod3", "none"]

#name of .txt file
name = 'dist3.txt'
name3 = 'dist3'

#converting images
cvt.BinaryHistTXT(name, dist3)
cvt.BinaryShapesTXT(name3, dist3)

#dist4 class
dist4 = ["data/mod4", "none"]

#name of .txt file
name = 'dist4.txt'
name4 = 'dist4'

#converting images
cvt.BinaryHistTXT(name, dist4)
cvt.BinaryShapesTXT(name4, dist4)

#
