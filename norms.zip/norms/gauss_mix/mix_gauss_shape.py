#
import numpy as np
import convert as cvt
import matplotlib.pyplot as plt
import random
import scipy.misc as sm
import imageio as ii


#example to show that SP is usable on multivariate normal
random.seed(7035982)

#random normal
mean1 = np.array((0,0))
mean2 = np.array((1,-1))
mean3 = np.array((-1,-1))
mean4 = np.array((0,-2))
cov1 = np.array( ( (.1, 0), (0, .1) ) )

#creating 100 random samples for each distribution
i=0
for i in range(100):
    #create random samples
    x1, y1 = np.random.multivariate_normal(mean1, cov1, 1000).T
    #convert dist1 to image
    H, xedges, yedges = np.histogram2d(x=x1, y=y1, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('mix_gauss_imgs/tad1/tad1_'+str(i)+'.png', img)

#creating 100 random samples for each distribution
i=0
for i in range(100):
    #create random samples
    x1, y1 = np.random.multivariate_normal(mean1, cov1, 1000).T
    x2, y2 = np.random.multivariate_normal(mean2, cov1, 1000).T
    x1 = np.concatenate((x1, x2))
    y1 = np.concatenate((y1, y2))
    #convert dist1 to image
    H, xedges, yedges = np.histogram2d(x=x1, y=y1, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('mix_gauss_imgs/tad2/tad2_'+str(i)+'.png', img)

#creating 100 random samples for each distribution
i=0
for i in range(100):
    #create random samples
    x1, y1 = np.random.multivariate_normal(mean1, cov1, 1000).T
    x2, y2 = np.random.multivariate_normal(mean2, cov1, 1000).T
    x3, y3 = np.random.multivariate_normal(mean3, cov1, 1000).T
    x1 = np.concatenate((x1, x2, x3))
    y1 = np.concatenate((y1, y2, y3))
    #convert dist1 to image
    H, xedges, yedges = np.histogram2d(x=x1, y=y1, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('mix_gauss_imgs/tad3/tad3_'+str(i)+'.png', img)

#creating 100 random samples for each distribution
i=0
for i in range(100):
    #create random samples
    x1, y1 = np.random.multivariate_normal(mean1, cov1, 1000).T
    x2, y2 = np.random.multivariate_normal(mean2, cov1, 1000).T
    x3, y3 = np.random.multivariate_normal(mean3, cov1, 1000).T
    x4, y4 = np.random.multivariate_normal(mean4, cov1, 1000).T
    x1 = np.concatenate((x1, x2, x3, x4))
    y1 = np.concatenate((y1, y2, y3, y4))
    #convert dist1 to image
    H, xedges, yedges = np.histogram2d(x=x1, y=y1, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('mix_gauss_imgs/tad4/tad4_'+str(i)+'.png', img)


#collecting shape metrics

#dist1 class
dist1 = ["mix_gauss_imgs/tad1", "none"]

#name of .txt file
name = 'tad1.txt'
name1 = 'tad1'

#converting images
cvt.BinaryHistTXT(name, dist1)
cvt.BinaryShapesTXT(name1, dist1)

#dist2 class
dist2 = ["mix_gauss_imgs/tad2", "none"]

#name of .txt file
name = 'tad2.txt'
name2 = 'tad2'

#converting images
cvt.BinaryHistTXT(name, dist2)
cvt.BinaryShapesTXT(name2, dist2)

#dist3 class
dist3 = ["mix_gauss_imgs/tad3", "none"]

#name of .txt file
name = 'tad3.txt'
name3 = 'tad3'

#converting images
cvt.BinaryHistTXT(name, dist3)
cvt.BinaryShapesTXT(name3, dist3)

#dist4 class
dist4 = ["mix_gauss_imgs/tad4", "none"]

#name of .txt file
name = 'tad4.txt'
name4 = 'tad4'

#converting images
cvt.BinaryHistTXT(name, dist4)
cvt.BinaryShapesTXT(name4, dist4)


#
