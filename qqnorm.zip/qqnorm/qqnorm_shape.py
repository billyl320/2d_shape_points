#
import numpy as np
import convert as cvt
import matplotlib.pyplot as plt
import random
import scipy.misc as sm
import imageio as ii

import rpy2
import rpy2.robjects as robjects
from rpy2.robjects.packages import importr

# import R's "base" package
base = importr('base')
# import R's "stats" package
stats = importr('stats')

#example to show that SP is usable on multivariate normal
random.seed(91204051)

#creating 100 random samples for each distribution
i=0
for i in range(100):
    #create random samples
    #sample 1
    temp = stats.rnorm(1000, 0, 1)
    x1, y1 = stats.qqnorm(y=temp, plot_it=False)
    x1 = np.array(x1)
    y1 = np.array(y1)
    #sample 2
    temp = stats.rnorm(990, 0, 1)
    temp2 = stats.rnorm(10, 3, 1)
    temp = base.c(temp, temp2)
    x2, y2 = stats.qqnorm(y=temp, plot_it=False)
    x2 = np.array(x2)
    y2 = np.array(y2)
    #sample 3
    temp = stats.rnorm(990, 0, 1)
    temp2 = stats.rnorm(10, 5, 1)
    temp = base.c(temp, temp2)
    x3, y3 = stats.qqnorm(y=temp, plot_it=False)
    x3 = np.array(x3)
    y3 = np.array(y3)
    #sample 4
    temp = stats.rnorm(990, 0, 1)
    temp2 = stats.rnorm(10, 10, 1)
    temp = base.c(temp, temp2)
    x4, y4 = stats.qqnorm(y=temp, plot_it=False)
    x4 = np.array(x4)
    y4 = np.array(y4)
    #convert dist1 to image
    H, xedges, yedges = np.histogram2d(x=x1, y=y1, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/q1/'+str(i)+'.png', img)
    #convert dist2 to image
    H, xedges, yedges = np.histogram2d(x=x2, y=y2, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/q2/'+str(i)+'.png', img)
    #convert dist3 to image
    H, xedges, yedges = np.histogram2d(x=x3, y=y3, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/q3/'+str(i)+'.png', img)
    #convert dist4 to image
    H, xedges, yedges = np.histogram2d(x=x4, y=y4, bins=(100, 100))
    img = (H>0.0)+0.0
    #save image in folder
    ii.imwrite('data/q4/'+str(i)+'.png', img)


#collecting shape metrics

#dist1 class
dist1 = ["data/q1", "none"]

#name of .txt file
name = 'dist1.txt'
name2 = 'dist1'

#converting images
cvt.BinaryHistTXT(name, dist1)
cvt.BinaryShapesTXT(name2, dist1)

#dist2 class
dist2 = ["data/q2", "none"]

#name of .txt file
name = 'dist2.txt'
name2 = 'dist2'

#converting images
cvt.BinaryHistTXT(name, dist2)
cvt.BinaryShapesTXT(name2, dist2)

#dist3 class
dist3 = ["data/q3", "none"]

#name of .txt file
name = 'dist3.txt'
name3 = 'dist3'

#converting images
cvt.BinaryHistTXT(name, dist3)
cvt.BinaryShapesTXT(name3, dist3)

#dist4 class
dist4 = ["data/q4", "none"]

#name of .txt file
name = 'dist4.txt'
name4 = 'dist4'

#converting images
cvt.BinaryHistTXT(name, dist4)
cvt.BinaryShapesTXT(name4, dist4)

#
